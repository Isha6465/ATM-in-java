import java.util.Scanner;

class Atm {
    int accountNumber = 786;
    int pin = 1234;
    double balance = 200000;
    float withdrawMoney;
    float depositeMoney;
    Scanner sc = new Scanner(System.in);

    public void login() {
        System.out.println("Enter Your Pin");
        int enterPin = sc.nextInt();
        System.out.println("Enter Your AccountNumber");
        int accountNumber = sc.nextInt();
        if (enterPin == pin && accountNumber == 786) {
            System.out.println("\t\t\t\t--------");
            System.out.println("\t\t\t\t|Welcome|");
            System.out.println("\t\t\t\t--------");
            System.out.println();
            menu();
        } else {
            System.out.println("You Entered Wrong Details");
            System.out.println("\t\t\tTry again!!!");
            login();
        }
    }

    public void menu() {
        System.out.println("\t\t\t\t------");
        System.out.println("\t\t\t\t|Menu|");
        System.out.println("\t\t\t\t------");

        System.out.println("1.To Check Balance");
        System.out.println("2.To Withdraw Money");
        System.out.println("3.To Deposite Money");
        System.out.println("4.To Check History");
        System.out.println("5.Exit");
        int option = sc.nextInt();
        if (option == 1) {
            checkBalance();
        } else if (option == 2) {
            withdrawMoney();
        } else if (option == 3) {
            depositeMoney();
        } else if (option == 4) {
            viewHistory();
        } else if (option == 5) {
            return;
        } else {
            System.out.println("    Invalid Choice Entered");
        }
    }

    void checkBalance() {
        System.out.println("Your A/C Balance is :$" + balance);
        menu();
    }

    void withdrawMoney() {
        System.out.println("Enter Ammount To Withdraw:$");
        withdrawMoney = sc.nextFloat();
        if (withdrawMoney <= balance) {
            balance = balance - withdrawMoney;
            System.out.println("Money withdrawn Successfully");
        } else {
            System.out.println("Insufficient Balance");
        }
        checkBalance();
        menu();
    }

    void depositeMoney() {
        System.out.println("Enter Amount To Deposite:$");
        depositeMoney = sc.nextFloat();
        balance = balance + depositeMoney;
        System.out.println("Deposite Money Succesfully");
        checkBalance();
        menu();
    }

    void viewHistory() {
        System.out.println("\t\t\t\t----------------------------");
        System.out.println("\t\t\t\t|This Is Your Account Histry|");
        System.out.println("\t\t\t\t-----------------------------");

        System.out.println("Your Current Balance is:$ " + balance);
        System.out.println("You Deposited Money:$" + depositeMoney);
        System.out.println("You Withdraw Money:$" + withdrawMoney);
        menu();
    }

}

public class ATM1 {
    public static void main(String[] args) {
        Atm obj = new Atm();
        obj.login();
    }
}